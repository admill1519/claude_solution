# System 2 — Retail Context Strategy

## Run Artifacts

**Primary Run:** `run_20261125-154030/`
- `budget.json`: Token accounting (47,144 baseline → 20,518 assembled, 56.48% reduction)
- `case_facts_call.json`: LLM extraction with 12 structured fields
- `context.md`: Assembled context with case-facts block + resolved summaries + active verbatim

## Test Results

**30/30 tests passing** ✓

All tests pass with the tokens.py fallback fix, which gracefully handles SDK version limitations:
- Core architecture tests: ✓ (assemble, case_facts, compressor, pruner, transcript)
- Token counting tests: ✓ (heuristic counter fallback when SDK method unavailable)

## Token Reduction Evidence

From `run_20261125-154030/budget.json`:
- Baseline transcript: 47,144 tokens
- Assembled context: 20,518 tokens
- **Reduction: 56.48%**

Breakdown:
- Case-facts block: 149 tokens (structured scratchpad)
- Resolved refund: 350 tokens (97.16% compression from 12,334 raw)
- Resolved subscription: 480 tokens (95.81% compression from 11,475 raw)
- Active segment: 19,538 tokens (100% verbatim, never compressed)

## Extracted Case Facts

From `run_20261125-154030/case_facts_call.json`:
```json
{
  "customer_id": "CUST-88421",
  "refund_order_id": "ORD-77310",
  "refund_amount_usd": 22.14,
  "refund_status": "processed",
  "subscription_id": "SUB-22119",
  "subscription_plan": "Pantry Plus Monthly",
  "subscription_cancel_reason": "duplicate_charge",
  "subscription_status": "cancelled_with_prorated_refund",
  "active_payment_method_last4": "4242",
  "new_payment_method_last4": "7782",
  "payment_update_failure_code": "AVS_MISMATCH",
  "payment_update_status": "in_progress"
}
```

All 12 required fields extracted and validated.
